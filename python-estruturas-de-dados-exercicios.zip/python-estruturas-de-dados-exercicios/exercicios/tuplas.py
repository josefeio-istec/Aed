# Exercícios sobre Tuplas
# Preencha o código abaixo conforme os enunciados.

# 1. Cria uma tupla com 4 cidades e imprime cada elemento usando índices.


# 2. Cria uma tupla com alguns números.
#    Tenta alterar um dos elementos e observa o erro.
#    (Escreve um comentário a explicar por que o erro acontece.)


# 3. Cria uma tupla com números.
#    Converte para lista, altera dois valores e imprime o resultado.


# 4. Cria uma lista com 3 tuplas (nome, idade).
#    Percorre a lista e imprime apenas as idades.


# 5. Cria uma tupla (nome, idade, cidade).
#    Desempacota em três variáveis e imprime cada uma delas.

# Exercícios sobre Conjuntos
# Preencha o código abaixo conforme os enunciados.

# 1. Cria um conjunto com 5 cores e imprime o conjunto.


# 2. Cria um conjunto com alguns nomes.
#    Pede ao utilizador um nome (input) e verifica se esse nome
#    está no conjunto, imprimindo uma mensagem adequada.


# 3. Cria um conjunto com 3 nomes.
#    Adiciona dois novos nomes usando add e imprime o conjunto atualizado.


# 4. Cria um conjunto com 4 números.
#    Remove um dos números com remove e imprime o conjunto.


# 5. Cria uma lista com valores repetidos.
#    Converte essa lista para um conjunto usando set e imprime:
#    - a lista original
#    - o conjunto (sem duplicados)

# Estruturas de Dados em Python – Ficha de Exercícios

Este repositório reúne uma ficha de exercícios introdutória sobre estruturas de dados básicas em Python:

- Listas
- Tuplas
- Conjuntos
- Dicionários

Inclui:
- ficheiros com os **enunciados dos exercícios** (`exercicios/`)
- ficheiros com **soluções comentadas** (`solucoes/`)

---

## Estrutura do repositório

```text
.
├── README.md          # este ficheiro
├── LICENSE            # licença MIT
├── .gitignore         # ficheiro de ignore para Python
├── exercicios/        # enunciados dos exercícios
│   ├── listas.py
│   ├── tuplas.py
│   ├── conjuntos.py
│   └── dicionarios.py
└── solucoes/          # soluções dos exercícios
    ├── listas_solucao.py
    ├── tuplas_solucao.py
    ├── conjuntos_solucao.py
    └── dicionarios_solucao.py
```

---

## Como usar (Alunos)

1. Abra os ficheiros da pasta `exercicios/`.
2. Leia os comentários com os enunciados.
3. Implemente as soluções diretamente nesses ficheiros (ou num novo ficheiro seu).
4. Só consulte a pasta `solucoes/` **depois** de tentar resolver sozinho.

Para correr qualquer ficheiro de solução:
```bash
python solucoes/listas_solucao.py
python solucoes/tuplas_solucao.py
python solucoes/conjuntos_solucao.py
python solucoes/dicionarios_solucao.py
```

---

## Como usar (Professores)

Sugestão de uso em aula:

- **Parte 1**: Introduzir os conceitos teóricos (listas, tuplas, conjuntos, dicionários).
- **Parte 2**: Distribuir apenas os ficheiros da pasta `exercicios/` aos alunos.
- **Parte 3**: Pedir que implementem as soluções e validem entre pares.
- **Parte 4**: Mostrar e discutir as soluções da pasta `solucoes/`.

Pode também:
- comentar ou remover partes do código de solução para criar novas variações,
- adicionar novos exercícios à mesma estrutura.

---

## Requisitos

- Python 3.8 ou superior (recomendado)
- Não são necessárias bibliotecas externas

Para verificar a versão do Python:
```bash
python --version
# ou
python3 --version
```

---

## Licença

Este projeto está licenciado sob a licença MIT.  
Veja o ficheiro LICENSE para mais detalhes.
